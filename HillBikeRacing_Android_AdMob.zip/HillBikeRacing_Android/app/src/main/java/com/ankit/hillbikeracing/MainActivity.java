package com.ankit.hillbikeracing;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.annotation.NonNull;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;

public class MainActivity extends Activity {
    private WebView webView;
    private InterstitialAd interstitialAd;

    private static final String LIVE_INTERSTITIAL_ID = "ca-app-pub-3422314458837062/1551457562";
    private static final String TEST_INTERSTITIAL_ID = "ca-app-pub-3940256099942544/1033173712";
    // Keep true while developing/testing. Set false only for your production build.
    private static final boolean USE_TEST_ADS = true;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new GameBridge(), "AndroidBridge");
        webView.loadUrl("file:///android_asset/index.html");

        new Thread(() -> MobileAds.initialize(this, status -> runOnUiThread(this::loadInterstitial))).start();
    }

    private void loadInterstitial() {
        AdRequest request = new AdRequest.Builder().build();
        InterstitialAd.load(this, USE_TEST_ADS ? TEST_INTERSTITIAL_ID : LIVE_INTERSTITIAL_ID, request,
            new InterstitialAdLoadCallback() {
                @Override public void onAdLoaded(@NonNull InterstitialAd ad) {
                    interstitialAd = ad;
                    interstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                        @Override public void onAdDismissedFullScreenContent() { interstitialAd = null; loadInterstitial(); }
                        @Override public void onAdFailedToShowFullScreenContent(@NonNull AdError e) { interstitialAd = null; loadInterstitial(); }
                    });
                }
                @Override public void onAdFailedToLoad(@NonNull LoadAdError e) { interstitialAd = null; }
            });
    }

    private void showGameOverAd() {
        if (interstitialAd != null) {
            InterstitialAd ad = interstitialAd;
            interstitialAd = null;
            ad.show(this);
        } else loadInterstitial();
    }

    private class GameBridge {
        @JavascriptInterface public void onGameOver() { runOnUiThread(MainActivity.this::showGameOverAd); }
    }

    @Override protected void onDestroy() {
        if (webView != null) { webView.removeJavascriptInterface("AndroidBridge"); webView.destroy(); }
        super.onDestroy();
    }
}
