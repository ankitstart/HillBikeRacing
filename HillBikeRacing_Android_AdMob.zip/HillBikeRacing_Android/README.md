# Hill Bike Racing — Android + AdMob

Your AdMob App ID and Interstitial Ad Unit ID are configured in this Android Studio project.

App ID: ca-app-pub-3422314458837062~1494608088
Ad Unit ID: ca-app-pub-3422314458837062/1551457562

The game reports Game Over to Android and Android shows a preloaded interstitial when one is available.

IMPORTANT: USE_TEST_ADS is true in MainActivity.java during development. Google recommends test ads while testing. Before publishing, verify the app and ad unit in your AdMob account and then change USE_TEST_ADS to false.

Do not click your own ads or encourage users to click ads. Ad revenue is not a fixed amount per Game Over; it depends on valid ad impressions and other AdMob factors.
